# Urban-Mobility-system

## Assignment file
https://hrnl.sharepoint.com/sites/CMI-ANL8-SQ-24-25/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FCMI%2DANL8%2DSQ%2D24%2D25%2FShared%20Documents%2FGeneral%2FFA%5FSQ%5F24%5F25%5FV1%5F1%2Epdf&parent=%2Fsites%2FCMI%2DANL8%2DSQ%2D24%2D25%2FShared%20Documents%2FGeneral

## Contributors
Chris van der Elst - 1029000 - Jacksn1219

Aymane Aazouz - 1073235 - ItzGalaxy15

Amer Alhasoun - 0992644 - ameralhasoun
